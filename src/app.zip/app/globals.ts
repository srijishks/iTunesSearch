import { Injectable } from '@angular/core';

Injectable()
export class Globals{
	
API_SEARCH_URL = "https://itunes.apple.com/search";
// API_SEARCH_URL = "http://sreejish.com/iTunesApi.php";
    
} 	