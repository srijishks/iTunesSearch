import { Component, ViewChild } from '@angular/core';
import { HeaderComponent } from './header/header.component';
import { ListComponent } from './list/list.component';
import { Globals } from './globals';
// import { MovieService } from './movie.service';

 // import { MessageComponent } from './message/message.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [ Globals ]
})
export class AppComponent {
  // title = 'app';
  // value = "";
	movie: any;
	message:string;
	listshow:boolean;

@ViewChild(HeaderComponent) headerComponent: HeaderComponent;
@ViewChild(ListComponent) listComponent: ListComponent;

onSearch(){
	console.log("this is in app com "+this.headerComponent.movie)	;
	this.movie = this.headerComponent.movie;
	if(this.movie!=undefined && this.movie.trim()!=""){
		this.message = "loading";
		this.listshow = true;
	}else{
		this.message = "novalue";
		this.listshow = false;
	}
}

onSearchComplete(status){
	// console.log("this is in srch reult - com "+this.listComponent)	;
	console.log('onSearchComplete')	;
	console.log(status)	;

	// this.listComponent.movie
	if(status == "failed"){
		console.log(status)	;
		this.message = "failed";
		this.listshow = false;
	}else if(status == "success"){
		console.log(status)	;
		this.message = "success";
		this.listshow = true;

	}else if(status == "noresult"){
		this.message = "noresult";	
		this.listshow = false;

	}
}

}
