import { ResolutionPipe } from './resolution.pipe';

describe('ResolutionPipe', () => {
  it('create an instance', () => {
    const pipe = new ResolutionPipe();
    expect(pipe).toBeTruthy();
  });
});
